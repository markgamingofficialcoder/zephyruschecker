# Project Closed

A Cc Checker by [Reboot13](https://t.me/reboot13)
This checker authenticate/charge depends on what type of site you use
1req= auth & 2req= charge
#note- 1-req is right now not accepting luminati so this checker is working on Ssl proxies
there may be so problem with proxies while 2req works on luminati,webshare,scrape-api etc

You can get CCN and CVV lives both from this checker doesn't mater 1req/2req
(1req need good proxies so every cards can get checked)


Create a file proxy.txt and add Proxies if you are not using zones

##Join Our support group [Telegram- Support group](https://t.me/cc_check)


Pull request commit changes

NOTE- Github hosting is just for Static website not dyanamic

You can only host html/css/js file on github not php

For hosting checker download master zip ,update api and host it on xampp(loaclhost) or 000webhost,or any other webhost


This api is just a Base
you have to find your own site and Fix api
Api Fixing Video is uploaded here
[Telegram- CC Checker](https://t.me/cc_checker)


Powered by [Shadow Monarch]

[Download Files](https://github.com/reboot13-git/cc-checker/archive/master.zip)

Follow me
Instagram
[krutik013](https://instagram.com/krutik013)
Twitter
[krutik013](https://twitter.com/krutik013)
Youtube
[Krutik Raut](https://www.youtube.com/channel/UCylCCoTTu_ULMYrqaiYMljA)
